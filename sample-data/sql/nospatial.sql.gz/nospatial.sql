--
-- PostgreSQL database dump
--


-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: sample_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sample_values (
    record_id integer NOT NULL,
    label text,
    value numeric,
    status text
);


--
-- Name: unicode_lookup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unicode_lookup (
    lookup_id integer NOT NULL,
    display_name text,
    category text
);


--
-- Data for Name: sample_values; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sample_values VALUES
	(1, 'Demo Value 1', 0.25, 'B'),
	(2, 'Demo Value 2', 0.50, 'C'),
	(3, 'Demo Value 3', 0.75, 'A'),
	(4, 'Demo Value 4', 1.00, 'B'),
	(5, 'Demo Value 5', 1.25, 'C'),
	(6, 'Demo Value 6', 1.50, 'A'),
	(7, 'Demo Value 7', 1.75, 'B'),
	(8, 'Demo Value 8', 2.00, 'C'),
	(9, 'Demo Value 9', 2.25, 'A'),
	(10, 'Demo Value 10', 2.50, 'B'),
	(11, 'Demo Value 11', 2.75, 'C'),
	(12, 'Demo Value 12', 3.00, 'A'),
	(13, 'Demo Value 13', 3.25, 'B'),
	(14, 'Demo Value 14', 3.50, 'C'),
	(15, 'Demo Value 15', 3.75, 'A'),
	(16, 'Demo Value 16', 4.00, 'B'),
	(17, 'Demo Value 17', 4.25, 'C'),
	(18, 'Demo Value 18', 4.50, 'A'),
	(19, 'Demo Value 19', 4.75, 'B'),
	(20, 'Demo Value 20', 5.00, 'C'),
	(21, 'Demo Value 21', 5.25, 'A'),
	(22, 'Demo Value 22', 5.50, 'B'),
	(23, 'Demo Value 23', 5.75, 'C'),
	(24, 'Demo Value 24', 6.00, 'A'),
	(25, 'Demo Value 25', 6.25, 'B'),
	(26, 'Demo Value 26', 6.50, 'C'),
	(27, 'Demo Value 27', 6.75, 'A'),
	(28, 'Demo Value 28', 7.00, 'B'),
	(29, 'Demo Value 29', 7.25, 'C'),
	(30, 'Demo Value 30', 7.50, 'A'),
	(31, 'Demo Value 31', 7.75, 'B'),
	(32, 'Demo Value 32', 8.00, 'C'),
	(33, 'Demo Value 33', 8.25, 'A'),
	(34, 'Demo Value 34', 8.50, 'B'),
	(35, 'Demo Value 35', 8.75, 'C'),
	(36, 'Demo Value 36', 9.00, 'A'),
	(37, 'Demo Value 37', 9.25, 'B'),
	(38, 'Demo Value 38', 9.50, 'C'),
	(39, 'Demo Value 39', 9.75, 'A'),
	(40, 'Demo Value 40', 10.00, 'B'),
	(41, 'Demo Value 41', 10.25, 'C'),
	(42, 'Demo Value 42', 10.50, 'A'),
	(43, 'Demo Value 43', 10.75, 'B'),
	(44, 'Demo Value 44', 11.00, 'C'),
	(45, 'Demo Value 45', 11.25, 'A'),
	(46, 'Demo Value 46', 11.50, 'B'),
	(47, 'Demo Value 47', 11.75, 'C'),
	(48, 'Demo Value 48', 12.00, 'A'),
	(49, 'Demo Value 49', 12.25, 'B'),
	(50, 'Demo Value 50', 12.50, 'C'),
	(51, 'Demo Value 51', 12.75, 'A'),
	(52, 'Demo Value 52', 13.00, 'B'),
	(53, 'Demo Value 53', 13.25, 'C'),
	(54, 'Demo Value 54', 13.50, 'A'),
	(55, 'Demo Value 55', 13.75, 'B'),
	(56, 'Demo Value 56', 14.00, 'C'),
	(57, 'Demo Value 57', 14.25, 'A'),
	(58, 'Demo Value 58', 14.50, 'B'),
	(59, 'Demo Value 59', 14.75, 'C'),
	(60, 'Demo Value 60', 15.00, 'A'),
	(61, 'Demo Value 61', 15.25, 'B'),
	(62, 'Demo Value 62', 15.50, 'C'),
	(63, 'Demo Value 63', 15.75, 'A'),
	(64, 'Demo Value 64', 16.00, 'B'),
	(65, 'Demo Value 65', 16.25, 'C'),
	(66, 'Demo Value 66', 16.50, 'A'),
	(67, 'Demo Value 67', 16.75, 'B'),
	(68, 'Demo Value 68', 17.00, 'C'),
	(69, 'Demo Value 69', 17.25, 'A'),
	(70, 'Demo Value 70', 17.50, 'B'),
	(71, 'Demo Value 71', 17.75, 'C'),
	(72, 'Demo Value 72', 18.00, 'A'),
	(73, 'Demo Value 73', 18.25, 'B'),
	(74, 'Demo Value 74', 18.50, 'C'),
	(75, 'Demo Value 75', 18.75, 'A'),
	(76, 'Demo Value 76', 19.00, 'B'),
	(77, 'Demo Value 77', 19.25, 'C'),
	(78, 'Demo Value 78', 19.50, 'A'),
	(79, 'Demo Value 79', 19.75, 'B'),
	(80, 'Demo Value 80', 20.00, 'C'),
	(81, 'Demo Value 81', 20.25, 'A'),
	(82, 'Demo Value 82', 20.50, 'B'),
	(83, 'Demo Value 83', 20.75, 'C'),
	(84, 'Demo Value 84', 21.00, 'A'),
	(85, 'Demo Value 85', 21.25, 'B'),
	(86, 'Demo Value 86', 21.50, 'C'),
	(87, 'Demo Value 87', 21.75, 'A'),
	(88, 'Demo Value 88', 22.00, 'B'),
	(89, 'Demo Value 89', 22.25, 'C'),
	(90, 'Demo Value 90', 22.50, 'A'),
	(91, 'Demo Value 91', 22.75, 'B'),
	(92, 'Demo Value 92', 23.00, 'C'),
	(93, 'Demo Value 93', 23.25, 'A'),
	(94, 'Demo Value 94', 23.50, 'B'),
	(95, 'Demo Value 95', 23.75, 'C'),
	(96, 'Demo Value 96', 24.00, 'A'),
	(97, 'Demo Value 97', 24.25, 'B'),
	(98, 'Demo Value 98', 24.50, 'C'),
	(99, 'Demo Value 99', 24.75, 'A'),
	(100, 'Demo Value 100', 25.00, 'B'),
	(101, 'Demo Value 101', 25.25, 'C'),
	(102, 'Demo Value 102', 25.50, 'A'),
	(103, 'Demo Value 103', 25.75, 'B'),
	(104, 'Demo Value 104', 26.00, 'C'),
	(105, 'Demo Value 105', 26.25, 'A'),
	(106, 'Demo Value 106', 26.50, 'B'),
	(107, 'Demo Value 107', 26.75, 'C'),
	(108, 'Demo Value 108', 27.00, 'A'),
	(109, 'Demo Value 109', 27.25, 'B'),
	(110, 'Demo Value 110', 27.50, 'C'),
	(111, 'Demo Value 111', 27.75, 'A'),
	(112, 'Demo Value 112', 28.00, 'B'),
	(113, 'Demo Value 113', 28.25, 'C'),
	(114, 'Demo Value 114', 28.50, 'A'),
	(115, 'Demo Value 115', 28.75, 'B'),
	(116, 'Demo Value 116', 29.00, 'C'),
	(117, 'Demo Value 117', 29.25, 'A'),
	(118, 'Demo Value 118', 29.50, 'B'),
	(119, 'Demo Value 119', 29.75, 'C'),
	(120, 'Demo Value 120', 30.00, 'A'),
	(121, 'Demo Value 121', 30.25, 'B'),
	(122, 'Demo Value 122', 30.50, 'C'),
	(123, 'Demo Value 123', 30.75, 'A'),
	(124, 'Demo Value 124', 31.00, 'B'),
	(125, 'Demo Value 125', 31.25, 'C'),
	(126, 'Demo Value 126', 31.50, 'A'),
	(127, 'Demo Value 127', 31.75, 'B'),
	(128, 'Demo Value 128', 32.00, 'C'),
	(129, 'Demo Value 129', 32.25, 'A'),
	(130, 'Demo Value 130', 32.50, 'B'),
	(131, 'Demo Value 131', 32.75, 'C'),
	(132, 'Demo Value 132', 33.00, 'A'),
	(133, 'Demo Value 133', 33.25, 'B'),
	(134, 'Demo Value 134', 33.50, 'C'),
	(135, 'Demo Value 135', 33.75, 'A'),
	(136, 'Demo Value 136', 34.00, 'B'),
	(137, 'Demo Value 137', 34.25, 'C'),
	(138, 'Demo Value 138', 34.50, 'A'),
	(139, 'Demo Value 139', 34.75, 'B'),
	(140, 'Demo Value 140', 35.00, 'C'),
	(141, 'Demo Value 141', 35.25, 'A'),
	(142, 'Demo Value 142', 35.50, 'B'),
	(143, 'Demo Value 143', 35.75, 'C'),
	(144, 'Demo Value 144', 36.00, 'A'),
	(145, 'Demo Value 145', 36.25, 'B'),
	(146, 'Demo Value 146', 36.50, 'C'),
	(147, 'Demo Value 147', 36.75, 'A'),
	(148, 'Demo Value 148', 37.00, 'B'),
	(149, 'Demo Value 149', 37.25, 'C'),
	(150, 'Demo Value 150', 37.50, 'A'),
	(151, 'Demo Value 151', 37.75, 'B'),
	(152, 'Demo Value 152', 38.00, 'C'),
	(153, 'Demo Value 153', 38.25, 'A'),
	(154, 'Demo Value 154', 38.50, 'B'),
	(155, 'Demo Value 155', 38.75, 'C'),
	(156, 'Demo Value 156', 39.00, 'A'),
	(157, 'Demo Value 157', 39.25, 'B'),
	(158, 'Demo Value 158', 39.50, 'C'),
	(159, 'Demo Value 159', 39.75, 'A'),
	(160, 'Demo Value 160', 40.00, 'B'),
	(161, 'Demo Value 161', 40.25, 'C'),
	(162, 'Demo Value 162', 40.50, 'A'),
	(163, 'Demo Value 163', 40.75, 'B'),
	(164, 'Demo Value 164', 41.00, 'C'),
	(165, 'Demo Value 165', 41.25, 'A'),
	(166, 'Demo Value 166', 41.50, 'B'),
	(167, 'Demo Value 167', 41.75, 'C'),
	(168, 'Demo Value 168', 42.00, 'A'),
	(169, 'Demo Value 169', 42.25, 'B'),
	(170, 'Demo Value 170', 42.50, 'C'),
	(171, 'Demo Value 171', 42.75, 'A'),
	(172, 'Demo Value 172', 43.00, 'B'),
	(173, 'Demo Value 173', 43.25, 'C'),
	(174, 'Demo Value 174', 43.50, 'A'),
	(175, 'Demo Value 175', 43.75, 'B'),
	(176, 'Demo Value 176', 44.00, 'C'),
	(177, 'Demo Value 177', 44.25, 'A'),
	(178, 'Demo Value 178', 44.50, 'B'),
	(179, 'Demo Value 179', 44.75, 'C'),
	(180, 'Demo Value 180', 45.00, 'A'),
	(181, 'Demo Value 181', 45.25, 'B'),
	(182, 'Demo Value 182', 45.50, 'C'),
	(183, 'Demo Value 183', 45.75, 'A'),
	(184, 'Demo Value 184', 46.00, 'B'),
	(185, 'Demo Value 185', 46.25, 'C'),
	(186, 'Demo Value 186', 46.50, 'A'),
	(187, 'Demo Value 187', 46.75, 'B'),
	(188, 'Demo Value 188', 47.00, 'C'),
	(189, 'Demo Value 189', 47.25, 'A'),
	(190, 'Demo Value 190', 47.50, 'B'),
	(191, 'Demo Value 191', 47.75, 'C'),
	(192, 'Demo Value 192', 48.00, 'A'),
	(193, 'Demo Value 193', 48.25, 'B'),
	(194, 'Demo Value 194', 48.50, 'C'),
	(195, 'Demo Value 195', 48.75, 'A'),
	(196, 'Demo Value 196', 49.00, 'B'),
	(197, 'Demo Value 197', 49.25, 'C'),
	(198, 'Demo Value 198', 49.50, 'A'),
	(199, 'Demo Value 199', 49.75, 'B'),
	(200, 'Demo Value 200', 50.00, 'C'),
	(201, 'Demo Value 201', 50.25, 'A'),
	(202, 'Demo Value 202', 50.50, 'B'),
	(203, 'Demo Value 203', 50.75, 'C'),
	(204, 'Demo Value 204', 51.00, 'A'),
	(205, 'Demo Value 205', 51.25, 'B'),
	(206, 'Demo Value 206', 51.50, 'C'),
	(207, 'Demo Value 207', 51.75, 'A'),
	(208, 'Demo Value 208', 52.00, 'B'),
	(209, 'Demo Value 209', 52.25, 'C'),
	(210, 'Demo Value 210', 52.50, 'A'),
	(211, 'Demo Value 211', 52.75, 'B'),
	(212, 'Demo Value 212', 53.00, 'C'),
	(213, 'Demo Value 213', 53.25, 'A'),
	(214, 'Demo Value 214', 53.50, 'B'),
	(215, 'Demo Value 215', 53.75, 'C'),
	(216, 'Demo Value 216', 54.00, 'A'),
	(217, 'Demo Value 217', 54.25, 'B'),
	(218, 'Demo Value 218', 54.50, 'C'),
	(219, 'Demo Value 219', 54.75, 'A'),
	(220, 'Demo Value 220', 55.00, 'B'),
	(221, 'Demo Value 221', 55.25, 'C'),
	(222, 'Demo Value 222', 55.50, 'A'),
	(223, 'Demo Value 223', 55.75, 'B'),
	(224, 'Demo Value 224', 56.00, 'C'),
	(225, 'Demo Value 225', 56.25, 'A'),
	(226, 'Demo Value 226', 56.50, 'B'),
	(227, 'Demo Value 227', 56.75, 'C'),
	(228, 'Demo Value 228', 57.00, 'A'),
	(229, 'Demo Value 229', 57.25, 'B'),
	(230, 'Demo Value 230', 57.50, 'C'),
	(231, 'Demo Value 231', 57.75, 'A'),
	(232, 'Demo Value 232', 58.00, 'B'),
	(233, 'Demo Value 233', 58.25, 'C'),
	(234, 'Demo Value 234', 58.50, 'A'),
	(235, 'Demo Value 235', 58.75, 'B'),
	(236, 'Demo Value 236', 59.00, 'C'),
	(237, 'Demo Value 237', 59.25, 'A'),
	(238, 'Demo Value 238', 59.50, 'B'),
	(239, 'Demo Value 239', 59.75, 'C'),
	(240, 'Demo Value 240', 60.00, 'A'),
	(241, 'Demo Value 241', 60.25, 'B'),
	(242, 'Demo Value 242', 60.50, 'C'),
	(243, 'Demo Value 243', 60.75, 'A'),
	(244, 'Demo Value 244', 61.00, 'B'),
	(245, 'Demo Value 245', 61.25, 'C'),
	(246, 'Demo Value 246', 61.50, 'A'),
	(247, 'Demo Value 247', 61.75, 'B'),
	(248, 'Demo Value 248', 62.00, 'C'),
	(249, 'Demo Value 249', 62.25, 'A'),
	(250, 'Demo Value 250', 62.50, 'B');


--
-- Data for Name: unicode_lookup; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.unicode_lookup VALUES
	(1, '照合項目001', '分類1'),
	(2, '照合項目002', '分類2'),
	(3, '照合項目003', '分類3'),
	(4, '照合項目004', '分類0'),
	(5, '照合項目005', '分類1'),
	(6, '照合項目006', '分類2'),
	(7, '照合項目007', '分類3'),
	(8, '照合項目008', '分類0');


--
-- Name: sample_values sample_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_values
    ADD CONSTRAINT sample_values_pkey PRIMARY KEY (record_id);


--
-- Name: unicode_lookup unicode_lookup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unicode_lookup
    ADD CONSTRAINT unicode_lookup_pkey PRIMARY KEY (lookup_id);


--
-- PostgreSQL database dump complete
--


